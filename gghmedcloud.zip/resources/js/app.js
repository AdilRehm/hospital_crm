require('./bootstrap');
$(function(){
    $('#datepicker').datepicker();
  });