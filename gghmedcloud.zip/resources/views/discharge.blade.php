@extends('layouts.app')
@section('title', 'Discharge')
@section('content')
    <div class="container-fluid">
        <form>
            <div class="row d-flex align-content-center">
                <h4 class="col-12 pb-2 text-start">Add Health Record</h4>
            </div>
            <div class="card shadow">
                <div class="card-body">
                    <div class="row">
                        <div class="col-auto">
                            <div class="input-group">
                                <input type="text" id="phone" class="form-control rounded-end rounded-5" name="phonenum" aria-describedby="btnGroupAddon" placeholder="Search By Name, Mr#, or Phone">
                                <div class="input-group-text bg-primary rounded-start rounded-5" id="btnGroupAddon"><i class="bi bi-search text-white"></i></div>
                            </div>
                        </div>
                        <div class="col-auto">
                            <button class="btn btn-primary"><strong>Add Patient</strong><i class="bi bi-plus"></i></button>
                        </div>
                        <div class="col-auto d-flex align-items-center">
                            <label class="form-label me-1 mt-2" for="doa">Date&nbsp;of&nbsp;Admission</label>
                            <input type="date" class="form-control rouded rounded-5" id="doa" name="date_admission">
                        </div>
                        <div class="col-auto d-flex align-items-center">
                            <label class="form-label me-1 mt-2" for="dod">Date&nbsp;of&nbsp;Discharge</label>
                            <input type="date" class="form-control rouded rounded-5" id="dod" name="date_discharge">
                        </div>
                    </div>
                </div>
            </div>
            <div class="card shadow">
                <div class="card-body ms-3 my-3">
                    <div class="accordion row" id="accordionExample">
                        <div class="col-md-auto p-0">
                            <h2 class="accordion-header" id="headingOne">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                <i class="bi bi-file-plus-fill fs-4"></i>Prescription
                                </button>
                            </h2>
                        </div>
                        <div class="col-md-auto p-0">
                            <h2 class="accordion-header" id="headingTwo">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                <i class="bi bi-bag-plus-fill fs-4"></i>Medication
                                </button>
                            </h2>
                        </div>
                        <div class="row">
                            <!-- Prescription medicine list form-->
                            <div class="col-md-12">
                                <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                    <div class="accordion-body row border">
                                        <div class="col-md-12 fs-5 p-0">
                                            <label>Co-Morbidity</label>
                                        </div>
                                        <div class="form-check col-md-3">
                                            <input class="form-check-input fs-5" type="checkbox" value="DIM" name="dim" id="dimcheck">
                                            <label class="form-check-label fs-5" for="dimcheck">
                                                DIM
                                            </label>
                                        </div>
                                        <div class="form-check col-md-3">
                                            <input class="form-check-input fs-5" type="checkbox" value="HTN" name="htn" id="vtncheck">
                                            <label class="form-check-label fs-5" for="vtncheck">
                                                HTN
                                            </label>
                                        </div>
                                        <div class="form-check col-md-3">
                                            <input class="form-check-input fs-5" type="checkbox" value="IHD" name="ihd" id="ihdcheck">
                                            <label class="form-check-label fs-5" for="ihdcheck">
                                                IHD
                                            </label>
                                        </div>
                                        <div class="form-check col-md-3">
                                            <input class="form-check-input fs-5" type="checkbox" value="CCF" name="ccf" id="ccfcheck">
                                            <label class="form-check-label fs-5" for="ccfcheck">
                                                CCF
                                            </label>
                                        </div>
                                        <div class="form-check col-md-3">
                                            <input class="form-check-input fs-5" type="checkbox" value="CVA" name="cva" id="cvacheck">
                                            <label class="form-check-label fs-5" for="cvacheck">
                                                CVA
                                            </label>
                                        </div>
                                        <div class="form-check col-md-3">
                                            <input class="form-check-input fs-5" type="checkbox" value="Dyslipidemia" name="dyslipidemia" id="Dyslipidemiacheck">
                                            <label class="form-check-label fs-5" for="Dyslipidemiacheck">
                                                Dyslipidemia
                                            </label>
                                        </div>
                                        <div class="form-check col-md-3">
                                            <input class="form-check-input fs-5" type="checkbox" value="Smoking" name="smoking" id="smokingcheck">
                                            <label class="form-check-label fs-5" for="smokingcheck">
                                                Smoking
                                            </label>
                                        </div>
                                        <div class="form-check col-md-3">
                                            <input class="form-check-input fs-5" type="checkbox" value="COPD/Asthma" name="copd/asthma" id="copd/asthmacheck">
                                            <label class="form-check-label fs-5" for="copd/asthmacheck">
                                                COPD/Asthma
                                            </label>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12 p-0 mt-2">
                                            <input type="textarea" class="form-control shadow" name="pres_other" placeholder="other">
                                        </div>
                                        <div class="col-md-12 mt-2 p-0">
                                            <label for="final_diagnose" class="form-label m-0 strong fs-6"><b>Final Diagnosis</b></label>
                                            <input type="text" class="form-control shadow" id="final_diagnose" name="finaldiagnose">
                                        </div>
                                        <div class=" col-md-12mt-2 p-0">
                                            <label for="presenting_complaint" class="form-label m-0 strong fs-6"><b>Presenting Complaint</b></label>
                                            <input type="text" class="form-control shadow" id="presenting_complaint" name="presentingcomplaint">
                                        </div>
                                        <div class="col-md-12 mt-2 p-0">
                                            <label for="hospitalstay" class="form-label m-0 strong fs-6"><b>Brief Notes of Hospital Stay</b></label>
                                            <input type="text" class="form-control shadow" id="hospitalstay" name="note_hospitalstay">
                                        </div>
                                        <div class="col-md-12 mt-2 p-0">
                                            <label for="significant_labs" class="form-label m-0 strong fs-6"><b>Significant Labs</b></label>
                                            <input type="text" class="form-control shadow" id="significant_labs" name="significantlabs">
                                        </div>
                                        <div class="col-md-12 mt-2 p-0">
                                            <label for="significant_past_history" class="form-label m-0 strong fs-6"><b>Significant Past History</b></label>
                                            <input type="text" class="form-control shadow" id="significant_past_history" name="significantpasthistory">
                                        </div>
                                        <div class="col-md-12 mb-3 mt-2 p-0">
                                            <label for="significant_past_history" class="form-label m-0 strong fs-6"><b>Follow Up Instructions</b></label>
                                            <div class="row ps-3">
                                                <div class="form-check col-md-3">
                                                    <input class="form-check-input fs-6" type="checkbox" value="تین دن کے بعد کمرہ نمبر 6 میں ریکارڈ کے ساتھ چیک کروایں" name="threedays" id="three_days">
                                                    <label class="form-check-label fs-6" for="three_days">
                                                    تین دن کے بعد کمرہ نمبر 6 میں ریکارڈ کے ساتھ چیک کروایں
                                                    </label>
                                                </div>
                                                <div class="form-check col-md-3">
                                                    <input class="form-check-input fs-6" type="checkbox" value="ایک ہفتہ کے بعد کمرہ نمبر 6 میں ریکارڈ کے ساتھ چیک کروایں" name="oneweek" id="one_week">
                                                    <label class="form-check-label fs-6" for="one_week">
                                                    ایک ہفتہ کے بعد کمرہ نمبر 6 میں ریکارڈ کے ساتھ چیک کروایں
                                                    </label>
                                                </div>
                                                <div class="form-check col-md-3">
                                                    <input class="form-check-input fs-6" type="checkbox" value="دو ہفتہ کے بعد کمرہ نمبر 6 میں ریکارڈ کے ساتھ چیک کروایں" name="twoweek" id="two_week">
                                                    <label class="form-check-label fs-6" for="two_week">
                                                    دو ہفتہ کے بعد کمرہ نمبر 6 میں ریکارڈ کے ساتھ چیک کروایں
                                                    </label>
                                                </div>
                                                <div class="form-check col-md-3">
                                                    <input class="form-check-input fs-6" type="checkbox" value="ایک ماہ کے بعد کمرہ نمبر 6 میں ریکارڈ کے ساتھ چیک کروایں" name="onemonth" id="one_month">
                                                    <label class="form-check-label fs-6" for="one_month">
                                                    ایک ماہ کے بعد کمرہ نمبر 6 میں ریکارڈ کے ساتھ چیک کروایں
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12 p-0 mt-2">
                                            <input type="textarea" class="form-control shadow" name="pres_other" placeholder="other">
                                        </div>
                                    </div> 
                                </div>
                            </div>

                             <!-- Medication section collapse list form-->
                             <div class="col-md-12">
                                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                                    <div></div>
                                    <div class="accordion-body" id="parent-container" >
                                        <div class="row  d-flex d-inline-flex" id="interface-container">
                                            <div class="col-md-3 mt-2 p-0">
                                                <label for="medication_name" class="form-label m-0 strong fs-6">Name</label>
                                                <input type="text" class="form-control shadow" id="medication_name" name="medicationname">
                                                <div class="d-flex">
                                                    <input type="text" class="form-control shadow" id="medication_name" name="medicationname" disabled>
                                                    <input type="text" class="form-control shadow" id="medication_name" name="medicationname" disabled>
                                                </div>
                                            </div>
                                            <div class="col-md-1 mt-2 p-0">
                                                <label for="medication_duration" class="form-label m-0 strong fs-6">Duration</label>
                                                <input type="text" class="form-control shadow" id="medication_duration" name="medicationduration">
                                                <select class="form-select" name="durationdays">
                                                    <option value="">Select</option>
                                                    <option value="days">Day(s)</option>
                                                    <option value="weeks">Week(s)</option>
                                                    <option value="months">Month(s)</option>
                                                    <option value="continously">Continously</option>
                                                    <option value="when required">When Required</option>
                                                    <option value="stat">STAT</option>
                                                    <option value="prn">PRN</option>
                                                </select>                                        
                                            </div>
                                            <div class="col-md-1 mt-2 p-0">
                                                <label for="medication_dosage" class="form-label m-0 strong fs-6">Dosage</label>
                                                <input type="text" class="form-control shadow" id="medication_dosage" name="medicationdosage">
                                                <select class="form-select" name="dosagetype">
                                                    <option value="">Select</option>
                                                    <option value="capsules">Capsule(s)</option>
                                                    <option value="tablet">Tablet(s)</option>
                                                    <option value="ml">ml</option>
                                                    <option value="mg">mg</option>
                                                    <option value="IU">IU</option>
                                                    <option value="drop">DROP</option>
                                                    <option value="tablespoon">Tablespoon</option>
                                                    <option value="teaspoon">Teaspoon(s)</option>
                                                    <option value="units">Unit(s)</option>
                                                    <option value="puff">Puff(s)</option>
                                                    <option value="sachet">Sachet</option>
                                                    <option value="ijection">Ijection</option>
                                                    <option value="dose step">Dose Step</option>
                                                    <option value="dropper">Dropper</option>
                                                    <option value="ml/h">ml/h</option>
                                                </select> 
                                            </div>
                                            <div class="col-md-2 mt-2 p-0">
                                                <label for="route_" class="form-label m-0 strong fs-6">Route</label>
                                                <select class="form-select" name="dosagetype" id="route_">
                                                    <option value="">Select Intake</option>
                                                    <option value="oral">Oral</option>
                                                    <option value="nasal">Nasal</option>
                                                    <option value="Intravenous">Intravenous</option>
                                                    <option value="topical">Topical</option>
                                                    <option value="Intraosseous">Intraosseous</option>
                                                    <option value="Intrathecal">Intrathecal</option>
                                                    <option value="Intraperitoneal">Intraperitoneal</option>
                                                    <option value="Intradernal">Intradernal</option>
                                                    <option value="Nasogastric">Nasogastric</option>
                                                    <option value="Sub Lingual">Sub Lingual</option>
                                                    <option value="Per Rectum">Per Rectum</option>
                                                    <option value="inhalation">Inhalation</option>
                                                    <option value="Intraoccular">Intraoccular</option>
                                                </select> 
                                            </div>
                                            <div class="col-md-2 mt-2 p-0">
                                                <label for="medication_frequency" class="form-label m-0 strong fs-6">Frequency</label>
                                                <select class="form-select" name="medicationfrequency" id="medication_frequency">
                                                    <option value="">Select</option>
                                                    <option value="oral">Only once</option>
                                                    <option value="nasal">Once a day</option>
                                                    <option value="Intravenous">Twice a day</option>
                                                    <option value="topical">Thrice a day</option>
                                                    <option value="Intraosseous">Four times a day</option>
                                                    <option value="Intrathecal">Before Bed</option>
                                                    <option value="Intraperitoneal">Every hour</option>
                                                    <option value="Intradernal">Every 2 hours</option>
                                                    <option value="Nasogastric">Every 3 hours</option>
                                                    <option value="Sub Lingual">Every 4 hours</option>
                                                    <option value="Per Rectum">Every 6 hours</option>
                                                    <option value="inhalation">Every 8 hours</option>
                                                    <option value="Intraoccular">Every 12 hours</option>
                                                    <option value="oral">Every Other day</option>
                                                    <option value="nasal">Every 3 days</option>
                                                    <option value="Intravenous">Once a Week</option>
                                                    <option value="topical">Twice a Week</option>
                                                    <option value="Intraosseous">Thrice a Week</option>
                                                    <option value="Intrathecal">Every 10 Days</option>
                                                    <option value="Intraperitoneal">Every 15 Days</option>
                                                    <option value="Intradernal">Once a month</option>
                                                    <option value="Nasogastric">Once a 3 months</option>
                                                    <option value="Sub Lingual">Once a Year</option>
                                                    <option value="Per Rectum">Every Morning</option>
                                                    <option value="inhalation">Every Evening</option>
                                                    <option value="Intraoccular">Every Night</option>
                                                    <option value="oral">If needed</option>
                                                    <option value="nasal">Before Breakfast</option>
                                                    <option value="Intravenous">Continously</option>
                                                    <option value="topical">Before Lunch</option>
                                                    <option value="Intraosseous">After Lunch</option>
                                                    <option value="Intrathecal">Before Meal</option>
                                                    <option value="Intraperitoneal">After Meal</option>
                                                    <option value="Intradernal">Before Dinner</option>
                                                    <option value="Nasogastric">After Dinner</option>
                                                    <option value="Sub Lingual">As Advised</option>
                                                    <option value="Per Rectum">Twice a month</option>
                                                    <option value="inhalation">After Breakfast</option>
                                                    <option value="Intraoccular">Before Breakfast and Lunch</option>
                                                    <option value="oral">Before Lunch and Dinner</option>
                                                    <option value="nasal">Before Breakfast and Dinner</option>
                                                    <option value="Intravenous">After Brealfast and Lunch</option>
                                                    <option value="topical">After Lunch and Dinner</option>
                                                    <option value="Intraosseous">Before Breakfast, Lunch & Dinner</option>
                                                    <option value="Intrathecal">After Breakfast, Lunch & Dinner at noon</option>
                                                    <option value="Intraperitoneal">Noon and Evening</option>
                                                    <option value="Intradernal">Morning, Evening, Night</option>
                                                    <option value="Nasogastric">Morning and Noon</option>
                                                    <option value="Sub Lingual">at 6am, 10am, 2pm, 6pm, 10pm</option>
                                                    <option value="Per Rectum">Thrice a day for 21 days, then only at night for next 2 months</option>
                                                    <option value="inhalation">Twice a day for 21 days, then only at night for next 2 months</option>
                                                    <option value="Intraoccular">Twice a day for 21 days, then onwards for next 2 months take 1 capsule by skipping 1 day</option>
                                                    <option value="oral">Twice a week after dialysis</option>
                                                    <option value="nasal">Thrice a week after dialysis</option>
                                                    <option value="Intravenous">After dialysis in double lumen</option>
                                                    <option value="topical">At the start of dialysis</option>
                                                    <option value="Intraosseous">During dialysis</option>
                                                    <option value="Intrathecal">Before dialysis</option>
                                                    <option value="Intraosseous">First injection now, then after 1 months, next at 2 months end, 3rd injection at 6 months end</option>
                                                    <option value="Intrathecal">Once a year</option>
                                                    <option value="Intrathecal">Once injection now, one after a month</option>
                                                    <option value="Intrathecal">Once injection now, one after a month, next after 6 months</option>
                                                </select> 
                                            </div>
                                            <div class="col-md-2 mt-2 p-0">
                                                <label for="medication_instruction" class="form-label m-0 strong fs-6">Instruction</label>
                                                <input type="text" class="form-control shadow" id="medication_instruction" name="medicationinstruction">
                                            </div>
                                            <div class="col-md-1 mt-2 p-0 d-flex align-items-center">
                                                <button class="btn btn-default delete-button" id="delete-button" name="medication_del"><i class="bi bi-trash3 fs-5"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12 d-flex justify-content-end mt-4">
                                            <button class="btn btn-primary" id="clone-button" name="medicine_add"><i class="bi bi-patch-plus"></i>Drugs</button>
                                        </div>
                                    </div>
                                </div>
                             </div>
                             <!-- end of Medication section collapse list form-->
                             <!-- <div class="col-md-6 mt-2 p-0">
                                            <label for="hospitalstay" class="form-label m-0 strong fs-6"><b>Improvement</b></label>
                                            <select class="form-select w-auto" name="improvement">
                                                <option value="">Select Improvement</option>
                                                <option value="0%">0%</option>
                                                <option value="10%">10%</option>
                                                <option value="20%">20%</option>
                                                <option value="30%">30%</option>
                                                <option value="40%">40%</option>
                                                <option value="50%">50%</option>
                                                <option value="60%">60%</option>
                                                <option value="70%">70%</option>
                                                <option value="80%">80%</option>
                                                <option value="90%">90%</option>
                                                <option value="100%">100%</option>
                                            </select>
                                        </div> -->
                                        <div class="col-md-12 p-0 mt-2 d-flex align-items-end">
                                            <button class="btn btn-primary me-2" type="submit" name="saveprint" id="save_print" onclick="">Save & Print</button>
                                            <button class="btn btn-primary" type="submit" name="save" id="saved" onclick="">Save</button>
                                        </div>
                         </div>
                    </div>
                </div>
            </div>
        </form>              
    </div>
@endsection