/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./public/js/custom.js":
/*!*****************************!*\
  !*** ./public/js/custom.js ***!
  \*****************************/
/***/ (() => {

eval("//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wdWJsaWMvanMvY3VzdG9tLmpzLmpzIiwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vLy4vcHVibGljL2pzL2N1c3RvbS5qcz80Zjk0Il0sInNvdXJjZXNDb250ZW50IjpbIiJdLCJtYXBwaW5ncyI6IiJ9\n//# sourceURL=webpack-internal:///./public/js/custom.js\n");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval-source-map devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./public/js/custom.js"]();
/******/ 	
/******/ })()
;
//alert("Hello testing phase 123");

// function generateinterface() {
//     var interface= document.getElementById("addusers");
//     var clone=interface.cloneNode(true);
//     document.body.appendChild(clone);
// }
// function generateinterface() {
//     // Get the interface element to clone
//     const interfaceToClone = document.querySelector('.accordion-body');
    
//     // Create a new interface element by cloning the original
//     const newInterface = interfaceToClone.cloneNode(true);
  
//     // Append the new interface element to the container element
//     const container = document.getElementById('interface-container');
//     container.appendChild(newInterface);
//   }

// Get references to the interface container and the clone/delete buttons
// ///////////////////////////////////
// const interfaceContainer = document.getElementById('interface-container');
// const cloneButton = document.getElementById('clone-button');
////////////////////////////////////////
//const deleteButton = document.getElementById('delete-button');

// // Add event listener to clone button
// cloneButton.addEventListener('click', () => {
//     event.preventDefault();
//   // Clone the interface element
//   const clonedInterface = interfaceContainer.cloneNode(true);
  
//   // Append the cloned interface element to the parent container
//   interfaceContainer.parentNode.appendChild(clonedInterface);
// });

// // Add event listener to delete button
// deleteButton.addEventListener('click', () => {
//     event.preventDefault();
//   // Remove the interface element
//   const clonedInterfaces = document.querySelectorAll('.cloned-interface');
//   if (clonedInterfaces.length > 0) {
//     // Delete the most recently added cloned interface
//     const lastClonedInterface = clonedInterfaces[clonedInterfaces.length - 1];
//     lastClonedInterface.parentNode.removeChild(lastClonedInterface);
//   }
//   else {
//     // Delete the original interface element
//     interfaceContainer.parentNode.removeChild(interfaceContainer);
//   }
// });
///////////////////////////////////////////
// const parentContainer = document.getElementById('parent-container');

// // Add event listener to clone button
// cloneButton.addEventListener('click', (event) => {
//   event.preventDefault();
//   // Clone the interface element
//   const clonedInterface = interfaceContainer.cloneNode(true);
  
//   // Append the cloned interface element to the parent container
//   parentContainer.appendChild(clonedInterface);
// });

// // Add event listener to parent container to handle clicks on delete button
// parentContainer.addEventListener('click', (event) => {
//   const target = event.target;
//   if (target.matches('.delete-button')) {
//     event.preventDefault();
//     // Remove the interface element
//     target.closest('.interface-container').remove();
//   }
// });
///////////////////////////////////////////////////////////////////////////////////
//clone code for delete modify
const interfaceContainer = document.getElementById('interface-container');
const cloneButton = document.getElementById('clone-button');
const parentContainer = document.getElementById('parent-container');

// Add event listener to clone button
let cloneIndex = 0;
cloneButton.addEventListener('click', (event) => {
  event.preventDefault();
  // Clone the interface element
  const clonedInterface = interfaceContainer.cloneNode(true);
  // Add data-index attribute to delete button
  clonedInterface.querySelector('.delete-button').setAttribute('data-index', cloneIndex);
  cloneIndex++;
  // Append the cloned interface element to the parent container
  parentContainer.appendChild(clonedInterface);
});

// Add event listener to parent container to handle clicks on delete button
parentContainer.addEventListener('click', (event) => {
  const target = event.target;
  if (target.matches('.delete-button')) {
    event.preventDefault();
    // Find the index of the cloned interface element
    const index = target.getAttribute('data-index');
    // Find the correct ancestor element using the index
    const interface = parentContainer.querySelector(`.interface-container[data-index="${index}"]`);
    // Remove the interface element
    interface.remove();
  }
});


//end for clone delete modify
// const container = document.getElementById('interface-container');
// const cloneButton = container.querySelector('#clone-button');
// const deleteButton = container.querySelector('#delete-button');

// // Add event listener to clone button
// cloneButton.addEventListener('click', () => {
//   // Clone the container element
//   const clonedContainer = container.cloneNode(true);
  
//   // Append the cloned container element to the parent container
//   container.parentNode.appendChild(clonedContainer);
// });

// // Add event listener to delete button
// deleteButton.addEventListener('click', () => {
//   // Remove the container element
//   container.parentNode.removeChild(container);
// });
  