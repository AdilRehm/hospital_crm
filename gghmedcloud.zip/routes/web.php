<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('dashboard');
});

Route::get('/medicine', function () {
    return view('medicine');
});

Route::get('/patient', function () {
    return view('patient');
});

Route::get('/discharge', function () {
    return view('discharge');
});
Route::get('/userrole', function () {
    return view('userrole');
});
// Route::get('views/{post}', function($slug){
//     $path=__DIR__."/../resources/views/{$slug}";
//     if(! file_exists($path))
//     {
//         abort(404);
//         return redirect('/');
//     }
//     $vieww=file_get_contents($path);
//     return view('post',['post'=>$vieww]);
// });

// Auth::routes();

// Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
