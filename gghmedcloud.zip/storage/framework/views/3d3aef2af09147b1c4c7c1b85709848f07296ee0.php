
<?php $__env->startSection('title', 'Add User'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
            <div class="row d-flex align-content-center">
                <h4 class="col-12 pb-2 text-start">User Role</h4>
            </div>
            <div class="card shadow">
                <div class="card-body ms-5 my-3">
                    <div class="accordion row" id="accordionExample">
                        <div class="col-md-auto p-0">
                            <h2 class="accordion-header" id="headingOne">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                Add User
                                </button>
                            </h2>
                        </div>
                        <div class="col-md-auto p-0">
                            <h2 class="accordion-header" id="usermodules">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#usermodulestwo" aria-expanded="false" aria-controls="usermodulestwo">
                                User Modules
                                </button>
                            </h2>
                        </div>
                        <div class="col-md-auto p-0">
                            <h2 class="accordion-header" id="useroperations">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#useroperationsthree" aria-expanded="false" aria-controls="useroperationsthree">
                                User Operations
                                </button>
                            </h2>
                        </div>
                        <div class="row">
                            <!-- Add User list form-->
                            <div class="col-md-12">
                                <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                    <div class="accordion-body row border">
                                        <form>
                                            <div class="row g-3 align-items-center">
                                                <div class="col-md-2">
                                                    <label for="doctorname" class="col-form-label"><strong>Name</strong></label>
                                                </div>
                                                <div class="col-md-10">
                                                    <input type="text" id="doctorname" required="required" class="form-control" name="doctor_name" aria-describedb="doctornamehelpname" placeholder="Name">
                                                </div>
                                                <div class="col-md-2">
                                                    <label for="doctorgender" class="col-form-label"><strong>Gender</strong></label>
                                                </div>
                                                <div class="col-md-10 d-flex flex-row justify-content-evenly">
                                                    <p class=""><input type="radio" class="form-checkbox" id="doctorgender" name="doctor_gender" value="Male" aria-describedby="genderhelpname">&nbsp;Gender</p>
                                                    <p class=""><input type="radio" class="form-checkbox" id="doctorgender" name="doctor_gender" value="Female" aria-describedby="genderhelpname">&nbsp;Female</p>
                                                    <p class=""><input type="radio" class="form-checkbox" id="doctorgender" name="doctor_gender" value="other" aria-describedby="genderhelpname">&nbsp;Other</p>
                                                </div>
                                                <div class="col-md-2">
                                                    <label for="doctorphone" class="col-form-label"><strong>Phone#</strong></label>
                                                </div>
                                                <div class="col-md-10">
                                                    <div class="input-group">
                                                        <div class="input-group-text" id="btnGroupAddon">+92</div>
                                                        <input type="text" required="required" id="doctorphone" class="form-control" name="doct_phonenum" aria-describedby="doctorphonehelp" placeholder="Phone Number">
                                                    </div>
                                                </div>
                                                <div class="col-md-2">
                                                    <label for="doctormail" class="col-form-label"><strong>Email*</strong></label>
                                                </div>
                                                <div class="col-md-10">
                                                    <input type="email" required="required" id="doctormail" class="form-control" name="doctor_mail" aria-describedby="doctormailhelp" placeholder="example@gmail.com">
                                                </div>
                                                <div class="col-md-2">
                                                    <label for="doctorpassword" class="col-form-label"><strong>Password</strong></label>
                                                </div>
                                                <div class="col-md-10 d-flex flex-row justify-content-evenly">
                                                    <input type="text" id="doctorpassword" class="form-control me-2" name="doctor_password" aria-describedby="doctorpasswordhekp" placeholder="Password">
                                                </div>
                                                <div class="col-md-12 mt-4">
                                                    <button type="submit" class="btn btn-primary" required="required" name="addpatient">Save User</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                             <!-- User Modules section collapse list form-->
                             <div class="col-md-12">
                                <div id="usermodulestwo" class="accordion-collapse collapse" aria-labelledby="usermodules" data-bs-parent="#accordionExample">
                                    <div class="accordion-body d-flex d-inline-flex">
                                        <form class="row">    
                                            <div class="col-md-2">
                                                <label for="usermodulename" class="col-form-label"><strong>Name</strong></label>
                                            </div>
                                            <div class="col-md-10">
                                                <input type="text" id="usermodulename" required="required" class="form-control" name="usermodule_name" aria-describedb="doctornamehelpname" placeholder="Name">
                                            </div>
                                            <div class="col-md-2">
                                                <label for="doctorrole" class="col-form-label"><strong>User Module</strong></label>
                                            </div>
                                            <div class="col-md-10 mt-3 mb-2 d-flex justify-content-around">
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input" id="doctorrole1" name="doctor_role1" value="Dashboard" aria-describedby="doctoraccesshelp">
                                                    <label class="form-check-label fs-6" for="doctorrole1">
                                                    Dashboard
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input" id="doctorrole2" name="doctor_role2" value="Medicine" aria-describedby="doctoraccesshelp">
                                                    <label class="form-check-label fs-6" for="doctorrole2">
                                                    Medicine
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input" id="doctorrole3" name="doctor_role3" value="Patient" aria-describedby="doctoraccesshelp">
                                                    <label class="form-check-label fs-6" for="doctorrole3">
                                                    Patient
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input" id="doctorrole4" name="doctor_role4" value="Discharge" aria-describedby="doctoraccesshelp">
                                                    <label class="form-check-label fs-6" for="doctorrole4">
                                                        Discharge
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="col-md-2">
                                                <label for="moduleremarks" class="col-form-label"><strong>Remarks:</strong></label>
                                            </div>
                                            <div class="col-md-10 d-flex flex-row justify-content-evenly">
                                                <input type="text" id="moduleremarks" class="form-control me-2" name="moduler_emarks" aria-describedby="moduleremarkshelp" placeholder="Remarks">
                                            </div>
                                            <div class="col-md-12 mt-4">
                                                <button type="submit" class="btn btn-primary" required="required" name="save_user_module">Save User Module</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                             </div>
                             <!-- User Operations section collapse list form-->
                             <div class="col-md-12">
                                <div id="useroperationsthree" class="accordion-collapse collapse" aria-labelledby="useroperations" data-bs-parent="#accordionExample">
                                    <div class="accordion-body d-flex d-inline-flex">
                                        <form class="row">
                                            <div class="col-md-2">
                                                <label for="useroperationsname" class="col-form-label"><strong>Name</strong></label>
                                            </div>
                                            <div class="col-md-10">
                                                <input type="text" id="useroperationsname" required="required" class="form-control" name="useroperation_name" aria-describedb="doctornamehelpname" placeholder="Name">
                                            </div>
                                            <div class="col-md-12 mt-1">
                                                <label for="doctorrole" class="col-form-label"><strong>User Operations:</strong></label>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input" id="doctorrole1" name="doctor_role1" value="Dashboard" aria-describedby="doctoraccesshelp">
                                                    <label class="form-check-label fs-6" for="doctorrole1">
                                                        View Dashboard
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input" id="doctorrole2" name="doctor_role2" value="Medicine" aria-describedby="doctoraccesshelp">
                                                    <label class="form-check-label fs-6" for="doctorrole2">
                                                        Medicine
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input" id="doctorrole3" name="doctor_role3" value="Patient" aria-describedby="doctoraccesshelp">
                                                    <label class="form-check-label fs-6" for="doctorrole3">
                                                        Patient
                                                    </label>                                                
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input" id="doctorrole4" name="doctor_role4" value="Discharge" aria-describedby="doctoraccesshelp">
                                                    <label class="form-check-label fs-6" for="doctorrole4">
                                                            Add/Update Discharge
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input" id="doctorrole4" name="doctor_role4" value="Radiology Manager" aria-describedby="doctoraccesshelp">
                                                    <label class="form-check-label fs-6" for="doctorrole4">
                                                        Creat Health Records
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input" id="doctorrole4" name="doctor_role4" value="Radiology Manager" aria-describedby="doctoraccesshelp">
                                                    <label class="form-check-label fs-6" for="doctorrole4">
                                                        Add Appointments
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input" id="doctorrole4" name="doctor_role4" value="Radiology Manager" aria-describedby="doctoraccesshelp">
                                                    <label class="form-check-label fs-6" for="doctorrole4">
                                                        View Patient
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input" id="doctorrole4" name="doctor_role4" value="Radiology Manager" aria-describedby="doctoraccesshelp">
                                                    <label class="form-check-label fs-6" for="doctorrole4">
                                                    Add/Update Patient
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input" id="doctorrole4" name="doctor_role4" value="Radiology Manager" aria-describedby="doctoraccesshelp">
                                                    <label class="form-check-label fs-6" for="doctorrole4">
                                                        Delete Patient
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="col-md-3">
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input" id="doctorrole4" name="doctor_role4" value="Radiology Manager" aria-describedby="doctoraccesshelp">
                                                    <label class="form-check-label fs-6" for="doctorrole4">
                                                        Edit/Update Medicine
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input" id="doctorrole4" name="doctor_role4" value="Radiology Manager" aria-describedby="doctoraccesshelp">
                                                    <label class="form-check-label fs-6" for="doctorrole4">
                                                        View Medicine
                                                    </label>
                                                </div>
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input" id="doctorrole4" name="doctor_role4" value="Radiology Manager" aria-describedby="doctoraccesshelp">
                                                    <label class="form-check-label fs-6" for="doctorrole4">
                                                        Delete Medicine
                                                    </label>
                                                </div>
                                            </div>
                                            <div class="col-md-2">
                                                <label for="operationremarks" class="col-form-label"><strong>Remarks:</strong></label>
                                            </div>
                                            <div class="col-md-10 mt-3 d-flex flex-row justify-content-evenly">
                                                <input type="text" id="operationremarks" class="form-control me-2" name="operation_emarks" aria-describedby="operationremarkshelp" placeholder="Remarks">
                                            </div>
                                            <div class="col-md-12 mt-4">
                                                <button type="submit" class="btn btn-primary" required="required" name="save_user_operation">Save User Operation</button>
                                            </div>
                                        </form>
                                    </div>     
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>           
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel projects\gghmedcloud\resources\views/userrole.blade.php ENDPATH**/ ?>