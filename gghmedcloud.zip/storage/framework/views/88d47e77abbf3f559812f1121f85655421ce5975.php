
<?php $__env->startSection('title', 'Medicine'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container w-50">
        <form class="mx-5">
            <div class="row d-flex align-content-center">
                <h4 class="col-12 pb-2 text-center">Add New Item</h4>
            </div>
            <div class="card shadow">
                <div class="card-body ms-5 my-3">
                    <div class="row g-3 align-items-center">
                        <div class="col-md-4">
                            <label for="itemname" class="col-form-label">Item Name</label>
                        </div>
                        <div class="col-md-8">
                            <input type="text" id="itemname" class="form-control" name="item_name" aria-describedby="itemnamehelpname" placeholder="Kindly enter Item name">
                        </div>
                        <div class="col-md-4">
                            <label for="salt" class="col-form-label">Salt</label>
                        </div>
                        <div class="col-md-8">
                            <input type="text" id="salt" class="form-control" name="item_salt" aria-describedby="salthelpname" placeholder="Kindly enter Salt">
                        </div>
                        <div class="col-md-4">
                            <label for="category" class="col-form-label">Category</label>
                        </div>
                        <div class="col-md-8">
                            <select class="form-select" id="category" name="item_category" aria-describedby="categoryhelpname">
                                <option value="">Search for Category</option>
                                <option value="Syrup">Syp</option>
                                <option value="Tablet">Tab</option>
                                <option value="Cap">Cap</option>
                                <option value="drop">Drop</option>
                                <option value="injection IV">Injection IV</option>
                                <option value="injection IM">Injection IM</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="remark" class="col-form-label">Remarks</label>
                        </div>
                        <div class="col-md-8">
                            <input type="text" id="remark" class="form-control" name="item_remarks" aria-describedby="salthelpname" placeholder="Kindly enter remarks">
                        </div>
                        <div class="col-md-12 text-center mt-4">
                            <button type="submit" class="btn btn-primary" id="medicine_submit" name="medicine_add">Add</button>
                        </div>
                    </div>
                </div>
            </div>
        </form>              
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel projects\gghmedcloud\resources\views/medicine.blade.php ENDPATH**/ ?>